#!/bin/bash

PROGNAME="TrackSync"
VERSION="0.1"

clean_up() { # Perform pre-exit housekeeping
    echo 'clean up '
    return
}

error_exit() {

    echo -e "\${PROGNAME}: \${1:-"Error - $1"}" >&2
    clean_up
    exit 1
}

graceful_exit() {
    clean_up
    exit
}

signal_exit() { # Handle trapped signals
    case \$1 in
    INT)
        error_exit "Program interrupted by user"
        ;;
    TERM)
        echo -e "\n\$PROGNAME: Program terminated" >&2
        graceful_exit
        ;;
    *)
        error_exit "\$PROGNAME: Terminating on unknown signal"
        ;;
    esac
}



INSTALL_DIR=$1

# VERIFY THAT DATA DIR ARGUMENT HAS BEEN PROVIDED
if [ -z "$INSTALL_DIR" ]; then
    echo "data dir not given"
   
    echo please enter full path of TrackSync directory 
    read -p 'TrackSync Dir: ' INSTALL_DIR
fi

# CHECK IF DATA DIRECTORY EXISTS; IF NOT CREATE ONE
if [ -d "$INSTALL_DIR" ]; then
    echo "Directory "$INSTALL_DIR" exists."
else
    echo "Directory $INSTALL_DIR not found. Creating Directory $INSTALL_DIR"
    mkdir $INSTALL_DIR
fi

